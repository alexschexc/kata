#!/bin/sh
# Double-click in Finder to run Kata in Terminal.
cd "$(dirname "$0")" || exit 1
xattr -d com.apple.quarantine ./kata 2>/dev/null
chmod +x ./kata
exec ./kata
